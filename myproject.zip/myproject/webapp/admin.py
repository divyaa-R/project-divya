from django.contrib import admin
from .models import song

# Register your models here.

admin.site.register(song)