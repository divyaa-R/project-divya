from django.db import models
from django.conf import settings
from django.utils import timezone
import time
from datetime import datetime
from datetime import date, timedelta as td
# Create your models here.
class song(models.Model):
    song_id = models.IntegerField(unique=True,null=True )
    song_name = models.CharField(max_length=100 ,null=True )
    duration  = models.PositiveIntegerField(null=True)
    time =  models.DateTimeField(auto_now=True)
    file_type = models.CharField(max_length=20 ,null=True )



    def __str__(self):
        return self.song_name



