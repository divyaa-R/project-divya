from rest_framework import serializers 
from webapp.models import song
 
 
class webappSerializer(serializers.ModelSerializer):
 
    class Meta:
        model = webapp
        fields = ('song_id ',
                  'song_name',
                  'duration',
                  ' time'
                  ' file_type')

class songview(APIView):

    def post(self, request):
        es = EventSerializer(data=request.data)
        if es.is_valid():
            es.save(user=self.request.user)
            return Response(status=status.HTTP_201_CREATED)
        return Response(data=es.errors, status=status.HTTP_400_BAD_REQUEST)