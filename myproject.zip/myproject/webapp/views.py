from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from webapp.models import song
from webapp.serializers import songserializer
from rest_framework.decorators import api_view

def redirect_view(request):
    response = redirect('/redirect-sucess/')
    return response



@api_view([ 'DELETE']) 
def song_list(request):
    if request.method == 'DELETE':
        count =song.delete('song_id','file_type')
        return response({'message': '{} it deleted successfully!'.format(count[0,1])}, status=status.HTTP_204_NO_CONTENT)










